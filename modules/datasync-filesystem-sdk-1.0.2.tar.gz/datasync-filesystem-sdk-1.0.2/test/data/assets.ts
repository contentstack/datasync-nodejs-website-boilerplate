export const assets = [
  {
    _version: 1,
    // tslint:disable-next-line: object-literal-sort-keys
    _content_type_uid: '_assets',
    locale: 'en-us',
    tags: ['1'],
    title: 'A 1',
    uid: 'a1',
    url:
    'https://images.contentstack.io/v3/assets/blt44d99c34b040fa61/blt6788d40f2aaaab9a/5c5aae49005d89b20bb85c21/cnn.png',
  },
  {
    _version: 1,
    // tslint:disable-next-line: object-literal-sort-keys
    _content_type_uid: '_assets',
    locale: 'en-us',
    tags: ['2'],
    title: 'A 2',
    uid: 'a2',
    url:
    'https://images.contentstack.io/v3/assets/blt44d99c34b040fa61/blt6788d40f2aaaab9a/5c5aae49005d89b20bb85c21/cnn.png',
  },
  {
    _version: 2,
    // tslint:disable-next-line: object-literal-sort-keys
    _content_type_uid: '_assets',
    locale: 'en-us',
    tags: ['3'],
    title: 'A 3',
    uid: 'a3',
    url:
    'https://images.contentstack.io/v3/assets/blt44d99c34b040fa61/blt6788d40f2aaaab9a/5c5aae49005d89b20bb85c21/cnn.png',
  },
]
