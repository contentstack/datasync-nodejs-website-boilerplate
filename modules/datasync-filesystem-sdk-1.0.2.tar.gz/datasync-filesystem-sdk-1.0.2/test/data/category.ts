export const entries = [
  {
    _content_type_uid: 'category',
    uid: 'c1',
    // tslint:disable-next-line: object-literal-sort-keys
    type: 'horror',
    locale: 'en-us',
    title: 'Cat One',
    tags: [],
  },
  {
    _content_type_uid: 'category',
    uid: 'c2',
    // tslint:disable-next-line: object-literal-sort-keys
    type: 'romance',
    locale: 'en-us',
    title: 'Cat One',
    tags: [],
  },
]